# CONDICIONES PARA MODO PACIENTE  
**Versión 1.0**

---

Requiere:
- Nueva versión del marco
- Rediseño de copy
- Seguridad adicional
- Validación clínica independiente

No reutilizar directamente v1.x.

---

## Estado del documento

Referencia futura, no implementable ahora.
