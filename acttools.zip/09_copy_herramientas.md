# COPY BASE POR HERRAMIENTA  
**Versión 1.0**

---

## Inicio
“Observa lo que aparece.”

## Durante
“No hagas nada con ello.”

## Cierre
“Nota que sigues aquí.”

---

(Variantes específicas se derivan de este patrón)

---

## Estado del documento

Copy mínimo funcional.
