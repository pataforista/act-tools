# CHECKLIST DE VALIDACIÓN CLÍNICA  
**Versión 1.0**

---

- ¿Facilita contacto?
- ¿Evita control?
- ¿No promete alivio?
- ¿Es abortable?
- ¿Respeta control clínico?

Si alguna falla → no integrar.
