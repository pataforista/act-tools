# FLUJOS CLÍNICOS TIPO  
**Versión 1.0**

---

## Sesión desorganizada
STOP → 5 Sentidos → Abrirse

## Rumiación
Visualizador → Radio → Matrix

## Bloqueo en valores
Diana → SMART-ACT

## Evitación crónica
DOTS → FEAR/DARE

---

## Estado del documento

Describe uso realista en sesión.
