# INTERACCIONES PERMITIDAS  
**Versión 1.0**

---

## Permitidas
- Tap
- Swipe simple
- Drag lento

---

## Prohibidas
- Gamificación
- Feedback de logro
- Animaciones celebratorias

---

## Estado del documento

UX al servicio del marco clínico.
