# VOZ Y COPY CLÍNICO  
**Versión 1.0**

---

## Persona narrativa
- Neutral
- Descriptiva
- No motivacional

---

## Reglas
- Frases cortas
- Segunda persona
- Sin promesas

---

## Permitido
- Observa
- Nota
- Permite
- Elige dirección

---

## Prohibido
- Controla
- Elimina
- Mejora
- Logra

---

## Estado del documento

Regula todo texto del sistema.
