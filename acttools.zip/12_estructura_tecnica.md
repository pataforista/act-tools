# ESTRUCTURA TÉCNICA MÍNIMA  
**Versión 1.0**

---

/public  
/index.html  

/src  
/app.js  
/modules/  
/components/  

/service-worker.js  

---

Offline-first.  
Sin backend obligatorio.

---

## Estado del documento

Base para MVP clínico.
